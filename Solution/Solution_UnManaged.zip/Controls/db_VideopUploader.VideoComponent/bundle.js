var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./VideoComponent/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./VideoComponent/index.ts":
/*!*********************************!*\
  !*** ./VideoComponent/index.ts ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.VideoComponent = void 0;\n\nvar EntityReference =\n/** @class */\nfunction () {\n  function EntityReference(typeName, id) {\n    this.id = id;\n    this.typeName = typeName;\n  }\n\n  return EntityReference;\n}();\n\nvar AttachedFile =\n/** @class */\nfunction () {\n  function AttachedFile(annotationId, fileName, mimeType, fileContent, fileSize) {\n    this.annotationId = annotationId;\n    this.fileName = fileName;\n    this.mimeType = mimeType;\n    this.fileContent = fileContent;\n    this.fileSize = fileSize;\n  }\n\n  return AttachedFile;\n}();\n\nvar VideoComponent =\n/** @class */\nfunction () {\n  function VideoComponent() {\n    var _this = this;\n\n    this.toBase64String = function (file, successFn) {\n      var reader = new FileReader();\n      reader.readAsDataURL(file);\n\n      reader.onload = function () {\n        return successFn(file, reader.result);\n      };\n\n      return reader.result;\n    };\n\n    this.uploadFn = function () {\n      debugger;\n      var fileUpload = document.getElementById('fileUpload');\n      var files = fileUpload.files;\n      var valid = fileUpload.files && fileUpload.files.length > 0;\n\n      if (!valid) {\n        alert('Please select the video file!');\n        return;\n      }\n\n      var file = fileUpload.files[0];\n\n      if (files[0].type != 'video/mp4') {\n        alert('Please attach only mp4 file!');\n        return;\n      }\n\n      _this.toBase64String(file, function (file, text) {\n        var type = file.type;\n\n        _this.renderToPlayer(text, type);\n\n        var notesEntity = new AttachedFile(\"\", file.name, type, text, file.size);\n\n        _this.addAttachments(notesEntity);\n      });\n    };\n\n    this.renderToPlayer = function (body, type) {\n      debugger;\n      var videoElement = document.getElementById('videoElement');\n      document.getElementById('elementPlayer').remove();\n      var sourceElement = document.createElement('source');\n      sourceElement.id = 'elementPlayer';\n      sourceElement.src = body;\n      sourceElement.type = type;\n      videoElement.appendChild(sourceElement);\n      videoElement.load();\n      console.log('body ' + body);\n      console.log(type);\n    };\n\n    this.showToPlayer = function (context, id) {\n      var notes = context.webAPI.retrieveRecord('annotation', id).then(function (attachment) {\n        var body = attachment.documentbody;\n        var type = attachment.mimetype;\n\n        _this.renderToPlayer(body, type);\n      });\n    };\n\n    this.addAttachments = function (file) {\n      debugger;\n      var notesEntity = {};\n      var fileContent = file.fileContent.replace(\"data:video/mp4;base64,\", \"\");\n      notesEntity[\"documentbody\"] = fileContent;\n      notesEntity[\"filename\"] = file.fileName;\n      notesEntity[\"filesize\"] = file.fileSize;\n      notesEntity[\"mimetype\"] = file.mimeType;\n      notesEntity[\"subject\"] = file.fileName;\n      notesEntity[\"notetext\"] = \"Video Attachment\";\n      notesEntity[\"objecttypecode\"] = _this.entityReference.typeName;\n      notesEntity[\"objectid_\" + _this.entityReference.typeName + \"@odata.bind\"] = \"/\" + _this.CollectionNameFromLogicalName(_this.entityReference.typeName) + \"(\" + _this.entityReference.id + \")\";\n      var thisRef = _this; // Invoke the Web API to creat the new record\n\n      _this._context.webAPI.createRecord(\"annotation\", notesEntity).then(function (response) {\n        // Callback method for successful creation of new record\n        console.log(response); // Get the ID of the new record created\n\n        notesEntity[\"annotationId\"] = response.id;\n        notesEntity[\"fileContent\"] = file.fileContent;\n        notesEntity[\"fileName\"] = notesEntity[\"filename\"];\n        this.renderToPlayer(file.fileContent, file.mimeType);\n        alert(\"Uploaded video successfully!!\");\n      }, function (errorResponse) {\n        // Error handling code here - record failed to be created\n        console.log(errorResponse);\n        alert(\"Unable to uploaded video!!\");\n      });\n    };\n\n    this.CollectionNameFromLogicalName = function (entityLogicalName) {\n      if (entityLogicalName[entityLogicalName.length - 1] != 's') {\n        return entityLogicalName + \"s\";\n      } else {\n        return entityLogicalName + \"es\";\n      }\n    };\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  VideoComponent.prototype.init = function (context, notifyOutputChanged, state, container) {\n    var _this = this;\n\n    this._context = context;\n    this.entityReference = new EntityReference(context.page.entityTypeName, context.page.entityId);\n    var labelUpload = document.createElement('label');\n    labelUpload.innerHTML = 'Upload Video: ';\n    container.appendChild(labelUpload);\n    var uploadInput = document.createElement('input');\n    uploadInput.id = 'fileUpload';\n    uploadInput.type = 'file';\n    uploadInput.accept = 'video/*';\n    uploadInput.setAttribute('style', 'opacity:1;width:50%;height:20px;position:inherit;pointer-events:inherit;');\n    container.appendChild(uploadInput);\n    var uploadBtn = document.createElement('button');\n    uploadBtn.innerHTML = 'Upload Video';\n\n    uploadBtn.onclick = function () {\n      return _this.uploadFn();\n    };\n\n    container.appendChild(uploadBtn);\n    var hrElement = document.createElement('hr');\n    container.appendChild(hrElement); // Add control initialization code\n\n    var videoElement = document.createElement('video');\n    videoElement.id = 'videoElement';\n    videoElement.width = 320;\n    videoElement.height = 240;\n    videoElement.controls = true;\n    var sourceElement = document.createElement('source');\n    sourceElement.id = 'elementPlayer';\n    sourceElement.src = 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4';\n    sourceElement.type = 'video/mp4';\n    videoElement.appendChild(sourceElement);\n    container.appendChild(videoElement);\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  VideoComponent.prototype.updateView = function (context) {// Add code to update control view\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  VideoComponent.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  VideoComponent.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  return VideoComponent;\n}();\n\nexports.VideoComponent = VideoComponent;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./VideoComponent/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('VideopUploader.VideoComponent', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.VideoComponent);
} else {
	var VideopUploader = VideopUploader || {};
	VideopUploader.VideoComponent = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.VideoComponent;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}